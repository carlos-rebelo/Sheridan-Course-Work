package yourturn4complete;

public interface AlarmHandler {

    void handleAlarm(AlarmEvent alarmEvent);
}
