package yourturn3;

public interface UpgradedMainframe {

    void accessUpgradedFunctionality();
}
