package javatopia;

public class EventObject {

    private String breadList = "5 Sourdough,  10 pumpernickel, 6 baguette, 14 croissant";

    public String getBreadList()
    {
        return "          Today's Bread " + breadList;
    }
}
