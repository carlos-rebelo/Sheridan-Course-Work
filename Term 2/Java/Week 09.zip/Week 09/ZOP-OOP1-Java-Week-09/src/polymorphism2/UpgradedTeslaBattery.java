package polymorphism2;

public interface UpgradedTeslaBattery {
    void access80PercentBattery();

    void accessLast20PercentBattery();
}
