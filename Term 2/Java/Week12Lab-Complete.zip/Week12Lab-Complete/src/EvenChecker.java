
public interface EvenChecker {
    boolean isEven(int number);
}
