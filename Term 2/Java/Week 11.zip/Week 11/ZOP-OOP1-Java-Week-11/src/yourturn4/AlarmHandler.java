package yourturn4;

public interface AlarmHandler {

    void handleAlarm(AlarmEvent alarmEvent);
}
