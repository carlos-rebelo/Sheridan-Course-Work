package buttonandlampcomplete;

public interface ButtonSwitchable {
    void acceptSignal();
}
