package interfaces;

public class Parrot {

}
