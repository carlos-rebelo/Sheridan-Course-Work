package buttonandlamp;

public class Heater {

}
