
@FunctionalInterface
public interface Blade {
    void use();
}
