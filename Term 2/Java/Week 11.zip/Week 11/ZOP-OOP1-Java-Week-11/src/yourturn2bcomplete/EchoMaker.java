package yourturn2bcomplete;

@FunctionalInterface
public interface EchoMaker {
    String echo(String phrase);

}
