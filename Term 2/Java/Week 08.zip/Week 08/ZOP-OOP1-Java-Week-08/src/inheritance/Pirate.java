package inheritance;

public class Pirate {

}
