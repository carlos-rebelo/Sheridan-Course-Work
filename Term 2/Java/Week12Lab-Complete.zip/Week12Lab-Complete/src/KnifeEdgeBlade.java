public class KnifeEdgeBlade implements Blade{

    @Override
    public void use() {
        System.out.println("using knife-edge blade to carve a branch");
    }

}
