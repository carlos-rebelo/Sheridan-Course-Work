package methodreferenceoperators;

public class Translator {

    public static void toStudent(String sentence)
    {
        System.out.println("Will" + sentence + " be on the test?");
    }

    public static void toPirate(String sentence)
    {
        System.out.println("Arrrrrrr," + sentence + ", you scurvy dog!");
    }

}
