package yourturn3;

import java.util.ArrayList;
import java.util.List;

public class PizzaOrder {
    protected int orderNumber;
    protected Size size;
    protected List<ToppingType> toppings = new ArrayList<>();
    private static int nextOrderNumber;

}
