package yourturn2;

public class SeeAndSay {

    // We need to be able to add animals to our See and Say and we need to be able to pull the string

}
