package polymorphism2;

public interface TemperatureSensor {
    int getTemperature();
}
