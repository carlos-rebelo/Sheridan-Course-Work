package yourturn4;

public class MyObject {

}
