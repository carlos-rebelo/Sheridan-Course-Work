package interfaces;

//We would like Pirate to implement ICharacter and IKillable
public class Pirate {

}
