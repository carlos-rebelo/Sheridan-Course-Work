package yourturn5;

public interface GenericStackable<T> {
    void push(T t);
}
