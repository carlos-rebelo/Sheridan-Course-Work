package yourturn1;

public class Product {
    private int id;
    private String name;
    private int requiredPoints;

    public Product(int id, String name, int requiredPoints) {
        this.id = id;
        this.name = name;
        this.requiredPoints = requiredPoints;
    }

    public int getId()
    {
        return id;
    }

    public String getName()
    {
        return name;
    }

    public int getRequiredPoints()
    {
        return requiredPoints;
    }

    @Override
    public String toString()
    {
        return "Product [id=" + id + ", name=" + name + ", requiredPoints=" + requiredPoints + "]";
    }

}