package interfaces;

public interface IKillable {
    void die();
}
