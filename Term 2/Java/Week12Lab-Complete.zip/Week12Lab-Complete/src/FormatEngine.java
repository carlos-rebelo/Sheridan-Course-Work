@FunctionalInterface
public interface FormatEngine {
    public String format(String text);

}
