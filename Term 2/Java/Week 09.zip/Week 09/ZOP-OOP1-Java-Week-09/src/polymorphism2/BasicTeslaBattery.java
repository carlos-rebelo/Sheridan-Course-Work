package polymorphism2;

public interface BasicTeslaBattery {
    void access80PercentBattery();
}
