package yourturn2acomplete;

public interface Honkable {
    void honk();
}
