package starthere;

public class StandardTorpedo implements Torpedo{

    @Override
    public void fire() {
        System.out.println("Firing standard Mark II torpedo");
    }

}
