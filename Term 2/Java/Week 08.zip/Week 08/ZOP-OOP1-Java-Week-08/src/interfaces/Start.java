package interfaces;

public class Start {
    public static void main(String[] args)
    {
        //Let's look at ICharacter
        Pirate pirate = new Pirate();
        Parrot parrot = new Parrot();
        //Let's make Pirate and Parrot implement ICharacter
        //Next, IKillable
    }
}
