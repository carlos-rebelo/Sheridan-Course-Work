package yourturn1complete;

/**
 * @Rich Smith at ZenOfProgramming.com
 */

public enum Coin
{
    NICKEL, DIME, QUARTER;
}
