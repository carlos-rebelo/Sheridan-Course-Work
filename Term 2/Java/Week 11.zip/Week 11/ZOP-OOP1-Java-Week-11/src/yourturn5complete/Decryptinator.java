package yourturn5complete;

@FunctionalInterface
public interface Decryptinator {
    String decrypt(String message);
}
