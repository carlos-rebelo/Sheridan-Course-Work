package yourturn1complete;

/**
 * @Rich Smith at ZenOfProgramming.com
 */

public enum HeartBeat
{
    PITTERPATTER, THUMPITYTHUMP, BOOMCHICKA, FLIPITYFLOP
}
