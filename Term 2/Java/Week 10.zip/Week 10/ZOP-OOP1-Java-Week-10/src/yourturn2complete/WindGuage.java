package yourturn2complete;

/**
 * @Rich Smith at ZenOfProgramming.com
 */
public class WindGuage implements WindMeasurementDevice {

    @Override
    public WindData getWindData()
    {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
