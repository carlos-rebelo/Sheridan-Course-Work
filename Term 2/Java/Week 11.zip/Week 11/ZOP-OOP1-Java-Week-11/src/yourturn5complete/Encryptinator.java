package yourturn5complete;

@FunctionalInterface
public interface Encryptinator {
    String encrypt(String message);
}
