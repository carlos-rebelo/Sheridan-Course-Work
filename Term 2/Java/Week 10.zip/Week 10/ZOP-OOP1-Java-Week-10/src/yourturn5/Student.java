package yourturn5;

public class Student {
    private String name;

    private int studentNumber;

    public Student(String name, int studentNumber) {
        this.name = name;
        this.studentNumber = studentNumber;
    }

    public String getName()
    {
        return name;
    }

    public int getStudentNumber()
    {
        return studentNumber;
    }

}
