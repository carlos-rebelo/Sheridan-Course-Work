package yourturn5;

public class Calc {

}
