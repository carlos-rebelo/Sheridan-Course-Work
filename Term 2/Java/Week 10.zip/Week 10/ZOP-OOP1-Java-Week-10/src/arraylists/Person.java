package arraylists;

public class Person {
    public String name;
    private int govtIDNumber;

    public Person(String name, int govtIDNumber) {
        this.name = name;
        this.govtIDNumber = govtIDNumber;

    }

    @Override
    public String toString()
    {
        return "Person [name=" + name + ", govtIDNumber = " + govtIDNumber + "]";
    }

    ///hmmmm....why didn't the contains work with our ArrayList - something doesn't seem EQUAL to the challenge?

}
