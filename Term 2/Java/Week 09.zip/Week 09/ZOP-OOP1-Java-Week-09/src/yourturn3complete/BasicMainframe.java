package yourturn3complete;

public interface BasicMainframe {

    void accessBasicFunctionality();
}
