package gui;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

//We want out ButtonHandler to get notified if the button is clicked so we must implement EventHandler<MouseEvent>

public class MyButtonEventHandler1 {

}
