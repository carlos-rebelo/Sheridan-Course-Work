package yourturn2a;

public interface Honkable {
    void honk();
}
