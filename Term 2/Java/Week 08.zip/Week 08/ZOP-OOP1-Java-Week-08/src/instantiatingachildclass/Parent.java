package instantiatingachildclass;

public class Parent {

    public Parent() {
        System.out.println("In the Parent Constructor");
    }

}
