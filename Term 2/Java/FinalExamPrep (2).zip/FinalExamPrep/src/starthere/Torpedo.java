package starthere;

@FunctionalInterface
public interface Torpedo {
    void fire();
}
