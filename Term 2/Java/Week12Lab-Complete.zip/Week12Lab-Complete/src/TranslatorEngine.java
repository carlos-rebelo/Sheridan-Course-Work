public interface TranslatorEngine {
    String translate(String Sentence);
}
