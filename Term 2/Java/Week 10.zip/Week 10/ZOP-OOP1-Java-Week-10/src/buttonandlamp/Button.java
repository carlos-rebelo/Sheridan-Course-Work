package buttonandlamp;

public class Button {

    private final Lamp lamp;

    public Button() {
        lamp = new Lamp();
    }

    public void push()
    {
        lamp.acceptSignal();
    }
}
