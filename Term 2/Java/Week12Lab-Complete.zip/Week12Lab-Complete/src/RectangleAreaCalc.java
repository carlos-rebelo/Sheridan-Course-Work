
@FunctionalInterface
public interface RectangleAreaCalc {
    double calcAreaOfRectangle(double length, double width);
}
