package polymorphism1;

public class Student {

}
