package polymorphism1;

public class Pirate {

}
