package yourturn4complete;

public class MyObject {

    public void method1()
    {
        System.out.println("It works with our own objects!");
    }
}
