package yourturn1complete;

public class GrandChild extends Child {
    public GrandChild() {
        super(555);
        System.out.println("in the  constructor of GrandChild");
    }
}
