package buttonandlamp;

public interface ButtonSwitchable {
    void acceptSignal();
}
