package yourturn1complete;
/**
 * @Rich Smith at ZenOfProgramming.com
 */

public enum Power
{
    ON, OFF
}
