package instantiatingachildclass;

public class Start {
    public static void main(String[] args)
    {
        Child c1 = new Child();
    }
}
