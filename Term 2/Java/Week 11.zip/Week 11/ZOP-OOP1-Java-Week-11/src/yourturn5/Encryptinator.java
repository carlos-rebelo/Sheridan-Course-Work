package yourturn5;

@FunctionalInterface
public interface Encryptinator {
    String encrypt(String message);
}
