package polymorphism1;

public class Accountant {

}
