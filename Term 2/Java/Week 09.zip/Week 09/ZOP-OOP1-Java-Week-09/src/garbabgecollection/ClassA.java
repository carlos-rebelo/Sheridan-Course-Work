package garbabgecollection;

public class ClassA {
    private int num;

    public ClassA(int num) {
        this.num = num;
    }

}
