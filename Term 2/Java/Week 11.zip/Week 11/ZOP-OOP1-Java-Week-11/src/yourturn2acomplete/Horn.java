package yourturn2acomplete;

public class Horn implements Honkable {

    @Override
    public void honk()
    {
        System.out.println("Honk!");
    }

}
