package polymorphism1;

public interface CookieBaker {
    public void makeCookies();
}
