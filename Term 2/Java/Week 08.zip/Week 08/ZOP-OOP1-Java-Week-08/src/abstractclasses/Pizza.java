package abstractclasses;

public class Pizza {

}
