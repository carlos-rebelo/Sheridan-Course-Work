package yourturn2;

public class Dog extends Animal {

    @Override
    public String makeNoise()
    {
        return "bark bark bark!";
    }

}
