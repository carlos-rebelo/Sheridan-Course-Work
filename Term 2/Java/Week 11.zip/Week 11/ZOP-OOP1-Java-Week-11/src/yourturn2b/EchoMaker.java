package yourturn2b;

@FunctionalInterface
public interface EchoMaker {
    String echo(String phrase);

}
