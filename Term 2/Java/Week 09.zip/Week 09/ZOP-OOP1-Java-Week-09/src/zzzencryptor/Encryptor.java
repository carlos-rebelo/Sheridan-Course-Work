package zzzencryptor;

public interface Encryptor {

    String encrypt(String sentence);

    String decrypt(String sentence);
}
