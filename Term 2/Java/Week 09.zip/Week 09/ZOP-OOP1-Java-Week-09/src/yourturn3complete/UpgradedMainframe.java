package yourturn3complete;

public interface UpgradedMainframe {

    void accessUpgradedFunctionality();
}
