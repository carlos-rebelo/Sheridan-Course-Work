package abstractclasses;

public class IceCream {

}
