package yourturn3complete;

public class Item {
    protected int skuNumber;
    protected String itemName;
    protected String itemDescription;
}
