package yourturn5;

@FunctionalInterface
public interface Decryptinator {
    String decrypt(String message);
}
