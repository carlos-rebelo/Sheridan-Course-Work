package yourturn1;

public class Parent {

    private int instVar;

    public void method1()
    {
        System.out.println("In method1 of Parent");
    }

    public void method2()
    {
        System.out.println("In method2 of Parent");
    }

}
