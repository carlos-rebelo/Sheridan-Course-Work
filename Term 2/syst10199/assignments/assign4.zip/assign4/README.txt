1. Unzip package

2. Open folder in VS Code. Make sure you are in the Assign4 directory that contains
controllers, models, views, etc. If you are not directly in the Assign4 directory it will not work

3. Open app.js and run the Code (Note: you may have to run npm install express/npm install ejs/npm init in terminal)

4. In your browser, go to localhost:3000, you will see an error message. that is fine.

5. Now, based on the operation you want to do, write the url localhost:3000/operation/num1/num2

6. /operation is replaced with the operation you want, which is either "add", "subtract", "divide", and "multiply"

7. Replace num1 and num2 with the numbers you want to perform the operation on

8. Example 1: localhost:3000/add/2/2 is equal to 2 + 2

9. Example 2: localhost:3000/subtract/20/10 is equal to 20 - 10