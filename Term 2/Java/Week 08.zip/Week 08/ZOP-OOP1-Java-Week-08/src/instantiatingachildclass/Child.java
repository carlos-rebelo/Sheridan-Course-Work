package instantiatingachildclass;

public class Child extends Parent {

    public Child() {
        System.out.println("In the child constructor");

    }

}
