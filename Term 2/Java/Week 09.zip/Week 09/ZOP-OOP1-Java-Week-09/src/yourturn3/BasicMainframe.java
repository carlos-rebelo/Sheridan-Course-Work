package yourturn3;

public interface BasicMainframe {
    void accessBasicFunctionality();
}
