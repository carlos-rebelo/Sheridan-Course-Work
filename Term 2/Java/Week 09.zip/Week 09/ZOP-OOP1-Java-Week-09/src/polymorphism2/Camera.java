package polymorphism2;

public interface Camera {
    void autoFocus();

    void takePhoto();

    void deletePhoto();

    void zoom(int percent);

}
