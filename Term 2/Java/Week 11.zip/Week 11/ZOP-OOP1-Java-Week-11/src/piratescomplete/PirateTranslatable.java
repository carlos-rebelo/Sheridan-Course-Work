package piratescomplete;

@FunctionalInterface
public interface PirateTranslatable {
    String translate(String sentence);
}
