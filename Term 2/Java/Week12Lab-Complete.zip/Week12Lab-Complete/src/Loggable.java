public interface Loggable {
    public String logObject();
}
