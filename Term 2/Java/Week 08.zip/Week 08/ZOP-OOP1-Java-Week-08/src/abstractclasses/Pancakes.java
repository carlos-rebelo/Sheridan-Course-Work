package abstractclasses;

public class Pancakes {

}
