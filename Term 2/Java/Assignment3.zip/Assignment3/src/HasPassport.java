public interface HasPassport {
    String talkToCustoms();
}
