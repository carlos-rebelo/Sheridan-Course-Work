package yourturn2;

public class Lion extends Animal {

    @Override
    public String makeNoise()
    {
        return "ROAR!!!";
    }

}
