package yourturn2a;

public class Start {
    public static void main(String[] args)
    {

        //Make Horn implement Honkable and show it working

        //use an inner-anonymous class to honk

        //Use  a lambda expression to honk

    }
}
