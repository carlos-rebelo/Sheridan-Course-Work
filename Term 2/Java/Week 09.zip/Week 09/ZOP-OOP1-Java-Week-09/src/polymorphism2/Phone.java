package polymorphism2;

public interface Phone {
    void makeCall(int number);

    void answerCall();

    void lookupContact();
}
