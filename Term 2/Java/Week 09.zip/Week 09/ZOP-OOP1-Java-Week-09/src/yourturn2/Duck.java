package yourturn2;

public class Duck extends Animal {

    @Override
    public String makeNoise()
    {
        return "Quack!";
    }

}
